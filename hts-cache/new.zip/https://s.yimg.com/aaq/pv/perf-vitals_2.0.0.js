<!DOCTYPE html>
<html lang="en-us">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Yahoo</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <style>
      html {
          height: 100%;
      }
      body {
          background: #fafafc url(https://s.yimg.com/nn/img/sad-panda-201402200631.png) 50% 50%;
          background-size: cover;
          height: 100%;
          text-align: center;
          font: 300 18px "helvetica neue", helvetica, verdana, tahoma, arial, sans-serif;
          margin: 0;
      }
      table {
          height: 100%;
          width: 100%;
          table-layout: fixed;
          border-collapse: collapse;
          border-spacing: 0;
          border: none;
      }
      h1 {
          font-size: 42px;
          font-weight: 400;
          color: #400090;
      }
      p {
          color: #1A1A1A;
      }
      #message-1 {
          font-weight: bold;
          margin: 0;
      }
      #message-2 {
          display: inline-block;
          *display: inline;
          zoom: 1;
          max-width: 17em;
          _width: 17em;
      }
      </style>
      <script>
      
      </script>
  </head>
  <body>
  <!-- status code : 416 -->
  <!-- Could not process this request -->
  <!-- host machine: e6.ycpi.deb.yahoo.com -->
  <!-- timestamp: 1668964932.902 -->
  <!-- url: https://s.yimg.com/aaq/pv/perf-vitals_2.0.0.js-->
  <script type="text/javascript">
    function buildUrl(url, parameters){
      var qs = [];
      for(var key in parameters) {
        var value = parameters[key];
        qs.push(encodeURIComponent(key) + "=" + encodeURIComponent(value));
      }
      url = url + "?" + qs.join('&');
      return url;
    }

    function generateBRBMarkup(site) {
      params.source = 'brb';
      generateBeaconMarkup(params);
      var englishHeader = 'Will be right back...';
      var englishMessage1 = 'Thank you for your patience.';
      var englishMessage2 = 'Our engineers are working quickly to resolve the issue.';
      var defaultLogoStyle = '';
      var siteDataMap = {
        'default': {
          logo: 'https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_p_205x58_frontpage.png',
          logoAlt: 'Yahoo Logo',
          logoStyle: defaultLogoStyle,
          header: englishHeader,
          message1: englishMessage1,
          message2: englishMessage2
        }
      };

      var siteDetails = siteDataMap['default'];

      document.write('<table><tbody><tr><td>');
      document.write('<div id="content">');
      document.write('<img src="' + siteDetails['logo'] + '" alt="' + siteDetails['logoAlt'] + '" style="' + siteDetails['logoStyle'] + '">');
      document.write('<h1 style="margin-top:20px;">' + siteDetails['header'] + '</h1>');
      document.write('<p id="message-1">' + siteDetails['message1'] + '</p>');
      document.write('<p id="message-2">' + siteDetails['message2'] + '</p>');
      document.write('</div>');
      document.write('</td></tr></tbody></table>');
    }

    function generateBeaconMarkup(params) {
        document.write('<img src="' + buildUrl('//geo.yahoo.com/b', params) + '" style="display:none;" width="0px" height="0px"/>');
        var beacon = new Image();
        beacon.src = buildUrl('//bcn.fp.yahoo.com/p', params);
    }

    var hostname = window.location.hostname;
    var device = 'featurephone';
    var ynet = ('-' === '1');
    var time = new Date().getTime();
    var params = {
        s: '1197757129',
        t: time,
        err_url: document.URL,
        err: '416',
        test: '-',
        ats_host: 'e6.ycpi.deb.yahoo.com',
        rid: '-',
        message: 'Could not process this request'
    };

    if(ynet) {
        document.write('<div style="height: 5px; background-color: red;"></div>');
    }
    generateBRBMarkup(hostname, params);

  </script>
  <noscript>
  <table>
    <tbody>
      <tr>
        <td>
          <div id="englishContent">
            <h1 style="margin-top:20px;">Will be right back...</h1>
            <p id="message-1">Thank you for your patience.</p>
            <p id="message-2">Our engineers are working quickly to resolve the issue.</p>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
  </noscript>
  </body>
</html>
